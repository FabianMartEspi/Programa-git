import { Component } from '@angular/core';

@Component({
  selector: 'app-filtros',
  standalone: true,
  imports: [],
  templateUrl: './facturas.component.html',
  styles: ``
})
export class FacturasComponent {

}
