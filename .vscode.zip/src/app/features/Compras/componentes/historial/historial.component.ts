import { Component } from '@angular/core';

@Component({
  selector: 'app-historial',
  standalone: true,
  imports: [],
  templateUrl: './historial.component.html',
  styles: ``
})
export class HistorialComponent {

}
