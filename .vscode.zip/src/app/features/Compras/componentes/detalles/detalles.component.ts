import { Component } from '@angular/core';

@Component({
  selector: 'app-detalles',
  standalone: true,
  imports: [],
  templateUrl: './detalles.component.html',
  styles: ``
})
export class DetallesComponent {

}
