import { Component } from '@angular/core';

@Component({
  selector: 'app-monitoreo',
  standalone: true,
  imports: [],
  templateUrl: './monitoreo.component.html',
  styles: ``
})
export class MonitoreoComponent {

}
