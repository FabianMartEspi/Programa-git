import { Component } from '@angular/core';

@Component({
  selector: 'app-continuar-compra',
  standalone: true,
  imports: [],
  templateUrl: './continuar-compra.component.html',
  styles: ``
})
export class ContinuarCompraComponent {

}
