import { Component } from '@angular/core';

@Component({
  selector: 'app-revisar-seleccion',
  standalone: true,
  imports: [],
  templateUrl: './revisar-seleccion.component.html',
  styles: ``
})
export class RevisarSeleccionComponent {

}
