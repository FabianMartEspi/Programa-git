import { Component } from '@angular/core';

@Component({
  selector: 'app-modificar-cantidades',
  standalone: true,
  imports: [],
  templateUrl: './modificar-cantidades.component.html',
  styles: ``
})
export class ModificarCantidadesComponent {

}
