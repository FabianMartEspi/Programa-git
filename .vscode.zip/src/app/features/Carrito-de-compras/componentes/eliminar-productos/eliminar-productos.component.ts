import { Component } from '@angular/core';

@Component({
  selector: 'app-eliminar-productos',
  standalone: true,
  imports: [],
  templateUrl: './eliminar-productos.component.html',
  styles: ``
})
export class EliminarProductosComponent {

}
