import { Component } from '@angular/core';

@Component({
  selector: 'app-agregar-productos',
  standalone: true,
  imports: [],
  templateUrl: './agregar-productos.component.html',
  styles: ``
})
export class AgregarProductosComponent {

}
