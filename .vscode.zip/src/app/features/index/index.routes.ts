import { Routes } from '@angular/router';
import { IndexComponent } from './home/index.component';


export const INDEX_ROUTES: Routes = [
  {
    path: '', 
    component: IndexComponent
  }
];

