import { Component } from '@angular/core';

@Component({
  selector: 'app-preguntas-frecuentes',
  standalone: true,
  imports: [],
  templateUrl: './preguntas-frecuentes.component.html',
  styles: ``
})
export class PreguntasFrecuentesComponent {

}
