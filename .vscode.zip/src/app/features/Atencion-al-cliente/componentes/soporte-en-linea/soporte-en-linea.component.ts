import { Component } from '@angular/core';

@Component({
  selector: 'app-soporte-en-linea',
  standalone: true,
  imports: [],
  templateUrl: './soporte-en-linea.component.html',
  styles: ``
})
export class SoporteEnLineaComponent {

}
