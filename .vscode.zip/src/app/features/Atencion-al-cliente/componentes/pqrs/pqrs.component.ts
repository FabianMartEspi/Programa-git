import { Component } from '@angular/core';
import { ChatBotModule } from "../chat-bot/chat-bot.module";

@Component({
  selector: 'app-pqrs',
  standalone: true,
  imports: [ChatBotModule],
  templateUrl: './pqrs.component.html',
  styles: ``
})
export class PQRSComponent {

}
