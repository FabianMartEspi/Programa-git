import { Component } from '@angular/core';

@Component({
  selector: 'app-politicas',
  standalone: true,
  imports: [],
  templateUrl: './politicas.component.html',
  styles: ``
})
export class PoliticasComponent {

}
