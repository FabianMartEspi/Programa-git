import { Component } from '@angular/core';

@Component({
  selector: 'app-protocolos',
  standalone: true,
  imports: [],
  templateUrl: './protocolos.component.html',
  styles: ``
})
export class ProtocolosComponent {

}
