import { Routes } from '@angular/router';
import { ContactoComponent } from './componente/contacto.component';


export const CONTACTO_EMPRESA: Routes = [
  {
    path: '', 
    component: ContactoComponent
  }
];


