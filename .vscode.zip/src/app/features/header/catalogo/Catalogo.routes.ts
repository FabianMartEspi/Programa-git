import { Routes } from '@angular/router';
import { CatalogoComponent } from './catalogo/catalogo.component';





export const CATALOGO_PRINCIPAL: Routes = [
  {
    path: '', 
    component: CatalogoComponent
  }
];


