import { Component } from '@angular/core';

@Component({
  selector: 'app-promociones',
  standalone: true,
  imports: [],
  templateUrl: './promociones.component.html',
  styles: ``
})
export class PromocionesComponent {

}
