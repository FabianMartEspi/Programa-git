import { Component } from '@angular/core';

@Component({
  selector: 'app-actualizaciones',
  standalone: true,
  imports: [],
  templateUrl: './actualizaciones.component.html',
  styles: ``
})
export class ActualizacionesComponent {

}
