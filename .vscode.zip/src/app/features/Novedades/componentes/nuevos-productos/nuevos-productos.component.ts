import { Component } from '@angular/core';

@Component({
  selector: 'app-nuevos-productos',
  standalone: true,
  imports: [],
  templateUrl: './nuevos-productos.component.html',
  styles: ``
})
export class NuevosProductosComponent {

}
