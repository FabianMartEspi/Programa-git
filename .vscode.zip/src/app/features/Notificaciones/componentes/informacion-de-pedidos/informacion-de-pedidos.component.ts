import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

interface Pedido {
  id: number;
  codigo: string;
  imagen: string;
  modelo: string;
  producto: string;
  fabricante: string;
  categoria: string;
  estado: string;
  precio: number;
}

@Component({
  selector: 'app-informacion-de-pedidos',
  standalone: true,
  imports: [FormsModule, CommonModule],
  templateUrl: './informacion-de-pedidos.component.html',
  styleUrls: ['./informacion-de-pedidos.component.css'],
})
export class InformacionDePedidosComponent {
  pedidos: Pedido[] = [
    // Ejemplo de pedidos
    {
      id: 1,
      codigo: '001',
      imagen: 'path/to/image1.jpg',
      modelo: 'Modelo A',
      producto: 'Producto A',
      fabricante: 'Fabricante A',
      categoria: 'Categoría A',
      estado: 'En Camino',
      precio: 100,
    },
    // ... Más pedidos simulados
  ];

  pedidosPaginados: Pedido[] = [];
  paginaActual = 1;
  pedidosPorPagina = 20;

  busquedaCodigo = '';
  busquedaNombre = '';
  filtroFabricante = '';
  fabricantes: string[] = ['Fabricante A', 'Fabricante B', 'Fabricante C'];

  get totalPaginas(): number {
    return Math.ceil(this.pedidos.length / this.pedidosPorPagina);
  }

  constructor() {
    this.cargarPedidos();
  }

  cargarPedidos() {
    const inicio = (this.paginaActual - 1) * this.pedidosPorPagina;
    const fin = inicio + this.pedidosPorPagina;
    this.pedidosPaginados = this.pedidos.slice(inicio, fin);
  }

  buscar() {
    console.log('Búsqueda:', this.busquedaCodigo, this.busquedaNombre, this.filtroFabricante);
    // Implementar lógica de búsqueda según filtros
  }

  siguientePagina() {
    if (this.paginaActual < this.totalPaginas) {
      this.paginaActual++;
      this.cargarPedidos();
    }
  }

  anteriorPagina() {
    if (this.paginaActual > 1) {
      this.paginaActual--;
      this.cargarPedidos();
    }
  }

  accionAdministrador(id: number) {
    console.log(`Acción tomada sobre el pedido con ID: ${id}`);
    // Implementar la lógica correspondiente
  }

  crearNuevoPedido() {
    console.log('Creando nuevo pedido...');
    // Implementar lógica para añadir un nuevo pedido
  }
}
