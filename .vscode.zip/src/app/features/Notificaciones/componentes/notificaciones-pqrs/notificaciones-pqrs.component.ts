import { Component } from '@angular/core';

@Component({
  selector: 'app-notificaciones-pqrs',
  standalone: true,
  imports: [],
  templateUrl: './notificaciones-pqrs.component.html',
  styles: ``
})
export class NotificacionesPQRSComponent {

}
