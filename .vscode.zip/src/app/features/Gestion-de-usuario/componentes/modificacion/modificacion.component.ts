import { Component } from '@angular/core';

@Component({
  selector: 'app-modificacion',
  standalone: true,
  imports: [],
  templateUrl: './modificacion.component.html',
  styles: ``
})
export class ModificacionComponent {

}
