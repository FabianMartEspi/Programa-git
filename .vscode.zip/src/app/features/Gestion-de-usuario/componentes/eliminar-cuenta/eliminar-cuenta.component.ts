import { Component } from '@angular/core';

@Component({
  selector: 'app-eliminar-cuenta',
  standalone: true,
  imports: [],
  templateUrl: './eliminar-cuenta.component.html',
  styles: ``
})
export class EliminarCuentaComponent {

}
