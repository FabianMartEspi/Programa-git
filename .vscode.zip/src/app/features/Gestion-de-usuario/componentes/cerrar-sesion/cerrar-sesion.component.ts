import { Component } from '@angular/core';

@Component({
  selector: 'app-cerrar-sesion',
  standalone: true,
  imports: [],
  templateUrl: './cerrar-sesion.component.html',
  styles: ``
})
export class CerrarSesionComponent {

}
