import { Component } from '@angular/core';

@Component({
  selector: 'app-blankpage',
  standalone: true,
  imports: [],
  templateUrl: './blankpage.component.html',
  styles: ``
})
export class BlankpageComponent {

}
