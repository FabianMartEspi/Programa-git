import { Component } from '@angular/core';

@Component({
  selector: 'app-autenticacion',
  standalone: true,
  imports: [],
  templateUrl: './autenticacion.component.html',
  styles: ``
})
export class AutenticacionComponent {

}
