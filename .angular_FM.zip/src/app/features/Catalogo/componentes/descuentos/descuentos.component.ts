import { Component } from '@angular/core';

@Component({
  selector: 'app-descuentos',
  standalone: true,
  imports: [],
  templateUrl: './descuentos.component.html',
  styles: ``
})
export class DescuentosComponent {

}
