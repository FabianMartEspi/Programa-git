import { Routes } from '@angular/router';
import { IngresarComponent } from './componente/ingresar.component';






export const INGRESA_TU_CUENTA: Routes = [
  {
    path: '', 
    component: IngresarComponent
  }
];


