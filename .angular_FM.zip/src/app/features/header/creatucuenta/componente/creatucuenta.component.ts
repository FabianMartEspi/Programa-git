import { Component } from '@angular/core';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-creatucuenta',
  standalone: true,
  imports: [RouterModule],
  templateUrl: './creatucuenta.component.html',
  styles: ``
})
export class CreatucuentaComponent {

}
