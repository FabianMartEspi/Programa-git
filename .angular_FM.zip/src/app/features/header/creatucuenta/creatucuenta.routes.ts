import { Routes } from '@angular/router';
import { CreatucuentaComponent } from './componente/creatucuenta.component';





export const CREA_TU_CUENTA: Routes = [
  {
    path: '', 
    component: CreatucuentaComponent
  }
];


