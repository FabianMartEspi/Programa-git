import { Routes } from '@angular/router';
import { NosotrosComponent } from './componet/nosotros.component';



export const NOSOTROS_PRINCIPAL: Routes = [
  {
    path: '', 
    component: NosotrosComponent
  }
];


