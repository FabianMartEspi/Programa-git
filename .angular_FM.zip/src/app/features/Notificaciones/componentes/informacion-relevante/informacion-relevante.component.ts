import { Component } from '@angular/core';

@Component({
  selector: 'app-informacion-relevante',
  standalone: true,
  imports: [],
  templateUrl: './informacion-relevante.component.html',
  styles: ``
})
export class InformacionRelevanteComponent {

}
