import { Component } from '@angular/core';

@Component({
  selector: 'app-historial-de-actividad',
  standalone: true,
  imports: [],
  templateUrl: './historial-de-actividad.component.html',
  styles: ``
})
export class HistorialDeActividadComponent {

}
