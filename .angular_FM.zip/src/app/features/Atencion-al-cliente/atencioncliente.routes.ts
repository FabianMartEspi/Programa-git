import { Routes } from '@angular/router';
import { ChatBotComponent } from './componentes/chat-bot/chat-bot.component';
import { PQRSComponent } from './componentes/pqrs/pqrs.component';
import { PreguntasFrecuentesComponent } from './componentes/preguntas-frecuentes/preguntas-frecuentes.component';
import { SoporteEnLineaComponent } from './componentes/soporte-en-linea/soporte-en-linea.component';


export const ATENCIONCLIENTE_CHATBOT: Routes = [
  {
    path: '', 
    component: ChatBotComponent
  }
];

export const ATENCIONCLIENTE_PQRS: Routes = [
  {
    path: '', 
    component: PQRSComponent
  }
];

export const ATENCIONCLIENTE_PREGUNTASF: Routes = [
  {
    path: '', 
    component: PreguntasFrecuentesComponent
  }
];
export const ATENCIONCLIENTE_SOPORTEENL: Routes = [
  {
    path: '', 
    component: SoporteEnLineaComponent
  }
];
